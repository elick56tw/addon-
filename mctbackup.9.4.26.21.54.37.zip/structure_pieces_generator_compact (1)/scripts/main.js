import {
    system,
    world,
    CustomCommandParamType,
    CustomCommandStatus
} from "@minecraft/server";

const GROUPS = {
    village_plains: "village/plains/",
    village_desert: "village/desert/",
    village_savanna: "village/savanna/",
    village_snowy: "village/snowy/",
    village_taiga: "village/taiga/",
    end_city: "end_city/",
    ruined_portal: "ruined_portal/",
    woodland_mansion: "woodland_mansion/"
};

const ROW_SIZE = 8;
const SPACING = 24;

function normalizeGroup(value) {
    if (typeof value === "string") {
        return value.toLowerCase();
    }

    if (value && typeof value === "object") {
        if (typeof value.value === "string") return value.value.toLowerCase();
        if (typeof value.name === "string") return value.name.toLowerCase();
    }

    return "";
}

function normalizeStructureId(id) {
    return String(id)
        .toLowerCase()
        .replace(/\\/g, "/")
        .replace(/^structures\//, "")
        .replace(/:/g, "/");
}

function matchesGroup(id, group) {
    const normalized = normalizeStructureId(id);

    // Only fix village matching. The command names and all other
    // structure groups remain unchanged.
    if (group.startsWith("village_")) {
        const biome = group.substring("village_".length);
        return normalized.startsWith(`village/${biome}/`);
    }

    const prefix = GROUPS[group];
    return typeof prefix === "string" &&
        normalized.startsWith(prefix);
}

function getStructures(group) {
    if (!GROUPS[group]) {
        return [];
    }

    return world.structureManager
        .getPackStructureIds()
        .filter(id => typeof id === "string")
        .filter(id => !normalizeStructureId(id).includes("/zombie/"))
        .filter(id => matchesGroup(id, group));
}

function generate(player, group) {
    const ids = getStructures(group);

    if (ids.length === 0) {
        player.sendMessage(
            `§cNo structure pieces found for §e${group}§c.`
        );
        return;
    }

    const base = {
        x: Math.floor(player.location.x),
        y: Math.floor(player.location.y),
        z: Math.floor(player.location.z)
    };

    ids.sort((a, b) => a.localeCompare(b));

    let placed = 0;

    for (let i = 0; i < ids.length; i++) {
        const id = ids[i];
        const col = i % ROW_SIZE;
        const row = Math.floor(i / ROW_SIZE);

        try {
            world.structureManager.place(
                id,
                player.dimension,
                {
                    x: base.x + col * SPACING,
                    y: base.y,
                    z: base.z + row * SPACING
                },
                {
                    includeBlocks: true,
                    includeEntities: true
                }
            );

            placed++;
        } catch (error) {
            console.warn(`[StructurePieces] Failed: ${id} | ${error}`);
        }
    }

    player.sendMessage(
        `§a${group} §7→ §e${placed}§7 structure pieces generated.`
    );
}

system.beforeEvents.startup.subscribe((init) => {
    const registry = init.customCommandRegistry;

    registry.registerEnum(
        "structurepieces:type",
        Object.keys(GROUPS)
    );

    registry.registerCommand(
        {
            name: "structurepieces:generate",
            description: "Generate all structure pieces in a structure group.",
            permissionLevel: 0,
            cheatsRequired: true,
            mandatoryParameters: [
                {
                    type: CustomCommandParamType.Enum,
                    name: "structurepieces:type"
                }
            ]
        },
        (origin, args) => {
            const player = origin.sourceEntity;
            const group = normalizeGroup(
                Array.isArray(args) ? args[0] : args
            );

            if (!player) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Run this command as a player."
                };
            }

            if (!GROUPS[group]) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: `Unknown structure group: ${group}`
                };
            }

            system.run(() => generate(player, group));

            return {
                status: CustomCommandStatus.Success
            };
        }
    );
});
