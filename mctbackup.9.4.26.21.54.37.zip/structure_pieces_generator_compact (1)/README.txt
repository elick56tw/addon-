Structure Pieces Generator - Final v2

Commands:
  /structurepieces:generate village_plains
  /structurepieces:generate village_desert
  /structurepieces:generate village_savanna
  /structurepieces:generate village_snowy
  /structurepieces:generate village_taiga
  /structurepieces:generate end_city
  /structurepieces:generate ruined_portal
  /structurepieces:generate woodland_mansion

The generator normalizes structure IDs so both namespace forms are accepted.
For example, village:desert/... and village/desert/... both match
village_desert.

All matching .mcstructure pieces are placed in a grid around the player.
